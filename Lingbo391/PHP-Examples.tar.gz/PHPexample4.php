<html>
    <body>
	<TABLE BORDER=2> 
		<?php  
		for ( $i=0;$i<10;$i++ ) {  
			?>  
			<TR> 
			<TD>Number</TD>
		        <TD><?php echo $i+1 ?></TD>  
			</TR>  
			<?php
		} ?>
	</TABLE>
    </body>
</html>
