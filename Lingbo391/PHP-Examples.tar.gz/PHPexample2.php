<html>
    <body>
	 <?php  $DATE=date(r);  ?>	
	 <p> Hello ! The time is now <?php echo $DATE ?> <p>
    </body>
</html>



