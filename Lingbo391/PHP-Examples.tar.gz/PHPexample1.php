<html>

    <body>
	<?php echo '<p>Hello ! The time is now '. date(r).'<p>';
        ?>
    </body>
</html>
